# Project 4: Batch Processing Engine

![Dashboard Preview](dashboard_preview.png)

## 🎯 Objective  
Build an end-to-end analytics pipeline that processes **96 raw CSV files** (4 regions × 12 months × 2 years) into a unified Power BI dashboard with MoM and YoY insights.

This simulates a real-world scenario where analysts receive monthly data dumps and must automate cleaning, validation, and visualization.

## 🔍 Key Features  
- ✅ **Python Batch Processor**: Loops through 96 files, cleans data, validates, logs errors  
- ✅ **Multi-Year Time Intelligence**: MoM % Change, YoY % Change using proper Date Table  
- ✅ **Interactive Dashboard**: Filter by Region, Category, Year  
- ✅ **Professional Documentation**: Clear folder structure, logs, and README

## ⚠️ Note on Aggregated % Change Totals  

You may notice very high total values for **MoM % Change (1731.7%)** or **YoY % Change (186.4%)** at the bottom of the table.

This is a **mathematical artifact**, not an error.

### Why?
- Percentages are **relative metrics** (e.g., “+50% from last month”)
- Summing them across different categories and months **has no statistical meaning**
- Example: +100% (from $10 → $20) + +900% (from $1 → $10) = **+1000% total** — but actual growth is only $11 → $30 (+172%)

### Best Practice
In real-world analytics:
- **Never sum % change values**
- Analyze trends **per segment** (e.g., by Region or Category)
- Use **absolute totals** (`Total Sales`) for overall performance
- If needed, calculate **weighted averages** for meaningful averages

This dashboard correctly computes **% change at the row level** — which is how business users interpret growth.

## 📁 Folder Structure  
*(You can reuse the one from Project 3, updated for Project 4)*

## 🚀 How to Reproduce  
1. Run `scripts/generate_dummy_files.py`  
2. Run `scripts/process_batch_files.py`  
3. Open `dashboard/Batch_Analytics_Dashboard.pbix` in Power BI  
4. Refresh to see dynamic MoM/YoY % Change

## 💼 Real-World Relevance  
This project mirrors core tasks in data analyst roles:
- Automating repetitive data ingestion  
- Building robust error-handling pipelines  
- Designing dashboards that tell truthful stories  
- Documenting work so others can reproduce it

---
Built with ❤️ by [Your Name] • Ready for Data Analyst roles in 2026
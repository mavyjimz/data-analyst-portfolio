# -*- coding: utf-8 -*-
import os
import pandas as pd
import logging
from datetime import datetime

# === SET UP LOGGING ===
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
logs_dir = os.path.join(project_root, "logs")
os.makedirs(logs_dir, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_file = os.path.join(logs_dir, f"batch_process_{timestamp}.log")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger()

# === START ===
logger.info("🚀 Starting Batch Processing Engine...")
logger.info(f"📁 Project root: {project_root}")

# === LOAD ALL FILES ===
raw_data_dir = os.path.join(project_root, "raw_data")
output_data_dir = os.path.join(project_root, "output_data")
os.makedirs(output_data_dir, exist_ok=True)

all_files = [f for f in os.listdir(raw_data_dir) if f.endswith('.csv')]
logger.info(f"📂 Found {len(all_files)} files to process")

# === PROCESS EACH FILE ===
dfs = []
for filename in all_files:
    filepath = os.path.join(raw_data_dir, filename)
    logger.info(f"📄 Processing: {filename}")
    
    try:
        df = pd.read_csv(filepath)
        
        # Clean: Ensure Sales is numeric
        df['Sales'] = pd.to_numeric(df['Sales'], errors='coerce')
        
        # Validate: Remove rows with missing Order ID or negative Sales
        df = df.dropna(subset=['Order ID'])
        df = df[df['Sales'] >= 0]
        
        # Add metadata
        parts = filename.replace('.csv', '').split('_')
        df['Region'] = parts[0]
        df['Month'] = parts[1]
        df['Year'] = parts[2]
        
        dfs.append(df)
        logger.info(f"✅ Processed: {filename} ({len(df)} rows)")
        
    except Exception as e:
        logger.error(f"❌ Failed to process {filename}: {e}")

# === COMBINE & SAVE ===
if dfs:
    combined_df = pd.concat(dfs, ignore_index=True)
    output_file = os.path.join(output_data_dir, "consolidated_sales_2025.csv")
    combined_df.to_csv(output_file, index=False)
    logger.info(f"💾 Saved consolidated data to: {output_file}")
    logger.info(f"📊 Total rows: {len(combined_df)}")
else:
    logger.warning("⚠️ No valid data found.")

logger.info("🎉 Batch Processing Engine completed successfully!")
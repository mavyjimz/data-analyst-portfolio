# -*- coding: utf-8 -*-
import os
import pandas as pd
import random
from datetime import datetime

# === SET UP PATHS ===
project_root = r"D:\My Road to Data Analyst\My Portfolio\Project_4_Batch_Processing_Engine"
raw_data_dir = os.path.join(project_root, "raw_data")
os.makedirs(raw_data_dir, exist_ok=True)

# === DEFINE CONFIG ===
regions = ["North", "South", "East", "West"]
months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
]
years = ["2024", "2025"]  # ← Now includes BOTH years

# === GENERATE FILES ===
for year in years:
    for region in regions:
        for month in months:
            n_rows = random.randint(500, 1500)
            # Add slight upward trend per year
            base_sales = 100 if year == "2024" else 120  # 2025 slightly higher
            sales_values = [round(base_sales + random.uniform(0, 300), 2) for _ in range(n_rows)]
            
            data = {
                "Order ID": [f"{region[:2]}-{year}-{i:04d}" for i in range(1, n_rows + 1)],
                "Order Date": pd.date_range(start=f"{year}-{months.index(month)+1:02d}-01", periods=n_rows, freq='D'),
                "Region": [region] * n_rows,
                "Sales": sales_values,
                "Category": random.choices(["Furniture", "Office Supplies", "Technology"], k=n_rows)
            }
            
            df = pd.DataFrame(data)
            filename = f"{region}_{month}_{year}.csv"
            filepath = os.path.join(raw_data_dir, filename)
            df.to_csv(filepath, index=False)
            print(f"✅ Generated: {filename} ({n_rows} rows)")

print(f"\n🎉 All {len(regions)*len(months)*len(years)} files generated!")
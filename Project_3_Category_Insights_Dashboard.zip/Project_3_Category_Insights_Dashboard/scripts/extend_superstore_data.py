# -*- coding: utf-8 -*-
import sys
import io

# Enable emojis in terminal (safe for personal use)
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import os
import pandas as pd
import logging
from datetime import datetime

# === SET UP LOGGING ===
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
logs_dir = os.path.join(project_root, "logs")
os.makedirs(logs_dir, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_file = os.path.join(logs_dir, f"extend_data_{timestamp}.log")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger()

# === START ===
logger.info("🚀 Starting Superstore Data Extender...")
logger.info(f"📁 Project root: {project_root}")

# === LOAD 2015 DATA ===
source_file = os.path.join(project_root, "..", "Project_1_Monthly_Sales_Tracker", "output_data", "clean_superstore_sales.csv")

if not os.path.exists(source_file):
    logger.error(f"❌ Source file not found: {source_file}")
    logger.error("   → Please run Project 1 first to generate clean data")
    exit(1)

logger.info(f"📊 Loading 2015 data from: {source_file}")
df_2015 = pd.read_csv(source_file)

# === CREATE 2016 COPY ===
logger.info("🔄 Creating 2016 copy...")
df_2016 = df_2015.copy()

# Update Order Date: 2015 → 2016
df_2016['Order Date'] = pd.to_datetime(df_2016['Order Date'], errors='coerce').apply(lambda x: x.replace(year=2016) if not pd.isna(x) else x)

# Update Year column
df_2016['Year'] = 2016

# === COMBINE DATA ===
df_extended = pd.concat([df_2015, df_2016], ignore_index=True)
logger.info(f"✅ Combined {len(df_2015)} (2015) + {len(df_2016)} (2016) = {len(df_extended)} rows")

# === SAVE EXTENDED DATA ===
data_dir = os.path.join(project_root, "data")
os.makedirs(data_dir, exist_ok=True)
output_file = os.path.join(data_dir, "extended_sales_data.csv")

df_extended.to_csv(output_file, index=False, date_format='%m/%d/%Y', encoding='utf-8')
logger.info(f"💾 Saved extended data to: {output_file}")

logger.info("🎉 Success! Extended Superstore data ready for Power BI.")
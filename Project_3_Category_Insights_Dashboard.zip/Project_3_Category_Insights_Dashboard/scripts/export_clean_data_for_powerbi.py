# -*- coding: utf-8 -*-
import sys
import io

# Enable emojis in terminal
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import os
import pandas as pd
import logging
from datetime import datetime

# === SET UP LOGGING ===
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)
logs_dir = os.path.join(project_root, "logs")
os.makedirs(logs_dir, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_file = os.path.join(logs_dir, f"export_clean_{timestamp}.log")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger()

# === START ===
logger.info("📤 Starting: Export Clean Data for Power BI")
logger.info(f"📁 Project root: {project_root}")

# === LOAD EXTENDED DATA ===
input_file = os.path.join(project_root, "data", "extended_sales_data.csv")

if not os.path.exists(input_file):
    logger.error(f"❌ Input file not found: {input_file}")
    logger.error("   → Run 'extend_superstore_data.py' first")
    exit(1)

logger.info(f"📊 Loading extended data from: {input_file}")
df = pd.read_csv(input_file)

# === CLEAN ORDER DATE ===
logger.info("🧹 Cleaning 'Order Date' column...")
df['Order Date'] = pd.to_datetime(df['Order Date'], errors='coerce')

# Remove any rows where Order Date is NaT (invalid)
initial_rows = len(df)
df = df.dropna(subset=['Order Date'])
final_rows = len(df)
logger.info(f"✅ Removed {initial_rows - final_rows} rows with invalid dates")

# === EXPORT TO EXCEL (WITH PROPER DATE FORMATTING) ===
output_excel = os.path.join(project_root, "data", "clean_for_powerbi.xlsx")

# Excel will preserve datetime as real date objects
df.to_excel(output_excel, index=False, engine='openpyxl')
logger.info(f"💾 Saved clean Excel file to: {output_excel}")

# === ALSO EXPORT CLEAN CSV (OPTIONAL) ===
output_csv = os.path.join(project_root, "data", "clean_for_powerbi.csv")
df.to_csv(output_csv, index=False, date_format='%m/%d/%Y')
logger.info(f"💾 Saved clean CSV to: {output_csv}")

logger.info("🎉 Success! Clean files ready for Power BI.")
logger.info("💡 Tip: Use 'clean_for_powerbi.xlsx' for best date compatibility.")
# Project 3: Category Insights Dashboard

![Dashboard Preview](dashboard_preview.png)

## 🎯 Objective  
Build an interactive Power BI dashboard that answers:  
> _"Which product categories are growing or declining year-over-year?"_

This project demonstrates **time intelligence, DAX mastery, and data storytelling** — critical skills for any Data Analyst.

## 🔍 Key Insights  
- **Technology** is the highest-revenue category  
- **Furniture** shows slight YoY decline  
- All YoY % changes are calculated dynamically using a **dedicated Date Table** (industry best practice)

## 🛠️ Technical Stack  
- **Data Source**: Simulated extended Superstore Sales (2015 → 2016)  
- **Power BI**: DAX measures, Date Table, Relationships  
- **Python**: Data extension & cleaning (see `scripts/`)  
- **File Format**: `.pbix` + `.xlsx` for reliable date handling

## 📊 Dashboard Features  
- **Line Chart**: Sales trend by category (2015–2016)  
- **YoY % Change Table**: Growth/decline per category  
- **Interactive Filters**: Year, Category  
- **Dynamic Title**: Updates on refresh

## 💡 Why This Matters  
> Many analysts struggle with Power BI’s time intelligence.  
> This project solves it the **right way**:  
> ✅ Dedicated `Date Table`  
> ✅ Proper relationships  
> ✅ Clean DAX (`SAMEPERIODLASTYEAR`, `CALCULATE`, `DIVIDE`)  

This is the **exact pattern used in enterprise analytics**.

## 📁 Folder Structure
# -*- coding: utf-8 -*-
import sys
import io

# Enable emojis in terminal (safe for personal use)
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import os
import pandas as pd
import logging
from datetime import datetime

# === SET UP LOGGING ===
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)  # e.g., Project_1_... folder
logs_dir = os.path.join(project_root, "logs")
os.makedirs(logs_dir, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_file = os.path.join(logs_dir, f"processing_{timestamp}.log")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger()

# === START PROCESSING ===
logger.info("🚀 Starting Monthly Sales Performance Tracker...")
logger.info(f"📁 Script location: {script_dir}")
logger.info(f"📂 Project root: {project_root}")

# === LOAD DATA ===
input_folder = os.path.join(project_root, "input_data")
source_file = os.path.join(input_folder, "Superstore_Sales.csv")

if not os.path.exists(source_file):
    logger.error(f"❌ File not found: {source_file}")
    logger.error("   → Please place Superstore_Sales.csv in 'input_data/'")
    exit(1)

logger.info(f"📊 Loading data from: {source_file}")
df = pd.read_csv(source_file)

# === VALIDATE COLUMNS ===
required_columns = ['Order Date', 'Sales', 'Category', 'Region']
missing = [col for col in required_columns if col not in df.columns]
if missing:
    logger.error(f"❌ Missing columns: {missing}")
    exit(1)

logger.info(f"✅ Loaded {len(df)} rows with {len(df.columns)} columns")

# === CLEAN DATA ===
logger.info("🧹 Cleaning data...")
# Convert Order Date to datetime
df['Order Date'] = pd.to_datetime(df['Order Date'], errors='coerce')
df = df.dropna(subset=['Order Date'])  # Remove invalid dates

# Remove negative sales (returns)
df = df[df['Sales'] > 0]

# Extract Year, Month, Quarter
df['Year'] = df['Order Date'].dt.year
df['Month'] = df['Order Date'].dt.month_name()
df['Quarter'] = df['Order Date'].dt.quarter

logger.info(f"✅ Cleaned data: {len(df)} rows remaining")

# === SAVE OUTPUT ===
output_folder = os.path.join(project_root, "output_data")
os.makedirs(output_folder, exist_ok=True)
output_file = os.path.join(output_folder, "clean_superstore_sales.csv")

df.to_csv(output_file, index=False, encoding='utf-8')
logger.info(f"💾 Saved cleaned data to: {output_file}")

logger.info("🎉 Success! Monthly Sales Processing Complete.")
logger.info("💡 Next: Open Power BI and connect to 'clean_superstore_sales.csv'")
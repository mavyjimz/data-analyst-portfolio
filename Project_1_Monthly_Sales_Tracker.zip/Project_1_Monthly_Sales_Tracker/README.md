# Project 1: Monthly Sales Performance Tracker

## 🎯 Problem
Client receives monthly sales files in mixed formats. They need:
- Automated cleaning of raw data
- MoM growth insights by category
- Executive-ready dashboard for trend analysis

## 🛠️ Solution
Built an end-to-end pipeline:
- Python script (`process_monthly_sales.py`) validates, cleans, and structures monthly data
- Power BI dashboard with DAX measures:
  - `Total Sales`
  - `MoM % Change` (with “N/A” handling)
- Clean output CSV → ready for BI consumption
- Full logging for auditability

## ▶️ How to Run
1. Place monthly file in `input_data/`
2. Run: `python scripts/process_monthly_sales.py`
3. Open `dashboard/Monthly_Sales_Dashboard.pbix`

## 📊 Preview
![Monthly Sales Dashboard](dashboard_preview.png)

## 💼 Real-World Value
> “This isn’t just a dashboard — it’s a **tested, documented system** that automates sales data processing and delivers MoM growth insights — ready to scale.”
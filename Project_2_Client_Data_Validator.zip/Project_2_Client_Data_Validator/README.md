# Project 2: Client Data Validator

## 🎯 Problem
Client sends messy sales files in mixed formats (CSV/Excel) with:
- Test records (`Customer = "TEST"`)
- Invalid regions (e.g., "Northh", "Westt")
- Inconsistent date formats
- No validation or audit trail

They need a reliable way to **clean and validate** data before analysis.

## 🛠️ Solution
Built a Python validation engine that:
- Accepts **CSV or Excel** files
- Applies **business rules**:
  - Removes test customers
  - Filters invalid regions (`["North", "South", "East", "West"]` only)
  - Validates and cleans `Order Date`
- Outputs **clean, structured CSV**
- Generates **detailed logs** for auditability
- Fully reusable for any client file

## ▶️ How to Run
1. Place client file in `input_data/` (rename to `Q4_Client_Data.xlsx` or `.csv`)
2. Run: `python scripts/validate_client_data.py`
3. Clean output appears in `output_data/clean_client_data.csv`

## 📊 Preview
*(This project focuses on data validation — output is a clean CSV ready for Power BI or reporting.)*

## 💼 Real-World Value
> “This isn’t just a script — it’s a **quality gate** that ensures only valid, trusted data enters the analysis pipeline.”
# -*- coding: utf-8 -*-
import sys
import io

# Enable emojis in terminal (safe for personal use)
if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import os
import pandas as pd
import logging
from datetime import datetime

# === SET UP LOGGING ===
script_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(script_dir)  # e.g., Project_2_... folder
logs_dir = os.path.join(project_root, "logs")
os.makedirs(logs_dir, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
log_file = os.path.join(logs_dir, f"validation_{timestamp}.log")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(log_file, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger()

# === START VALIDATION ===
logger.info("🚀 Starting Client Data Validator...")
logger.info(f"📁 Script location: {script_dir}")
logger.info(f"📂 Project root: {project_root}")

# === LOAD DATA ===
input_folder = os.path.join(project_root, "input_data")
source_file = os.path.join(input_folder, "Q4_Client_Data.xlsx")  # or .csv

if not os.path.exists(source_file):
    logger.error(f"❌ File not found: {source_file}")
    logger.error("   → Please place client file in 'input_data/'")
    exit(1)

logger.info(f"📊 Loading data from: {source_file}")
df = pd.read_excel(source_file)  # Use read_csv if it's CSV

# === VALIDATE COLUMNS ===
required_columns = ['Customer', 'Sales', 'Region', 'Order Date', 'Product Category']
missing = [col for col in required_columns if col not in df.columns]
if missing:
    logger.error(f"❌ Missing columns: {missing}")
    exit(1)

logger.info(f"✅ Loaded {len(df)} rows with {len(df.columns)} columns")

# === APPLY BUSINESS RULES ===
logger.info("🧹 Applying business rules...")

# Rule 1: Remove rows where Customer == "TEST"
initial_count = len(df)
df = df[df['Customer'] != 'TEST']
removed_test = initial_count - len(df)
logger.info(f"✅ Removed {removed_test} rows with Customer == 'TEST'")

# Rule 2: Remove invalid regions
valid_regions = ["North", "South", "East", "West"]
invalid_regions = df[~df['Region'].isin(valid_regions)]
if not invalid_regions.empty:
    logger.warning(f"⚠️ Found {len(invalid_regions)} rows with invalid regions: {invalid_regions['Region'].unique()}")
    df = df[df['Region'].isin(valid_regions)]
    logger.info(f"✅ Removed {len(invalid_regions)} rows with invalid regions")

# Rule 3: Keep negative sales (returns) — unless you want to remove them
# If you want to remove returns, uncomment next line:
# df = df[df['Sales'] >= 0]

# Rule 4: Convert Order Date to datetime
df['Order Date'] = pd.to_datetime(df['Order Date'], errors='coerce')
df = df.dropna(subset=['Order Date'])  # Remove invalid dates
logger.info(f"✅ Cleaned Order Date: {len(df)} rows remaining")

# === SAVE OUTPUT ===
output_folder = os.path.join(project_root, "output_data")
os.makedirs(output_folder, exist_ok=True)
output_file = os.path.join(output_folder, "clean_client_data.csv")

df.to_csv(output_file, index=False, encoding='utf-8')
logger.info(f"💾 Saved cleaned data to: {output_file}")

logger.info("🎉 Success! Client Data Validation Complete.")
logger.info("💡 Next: Open Power BI and connect to 'clean_client_data.csv'")